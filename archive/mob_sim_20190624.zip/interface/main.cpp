#include "gr_mainwin.h"
#include <QApplication>

//#include <QQuickView>
//#include "QtAndroidTools/QtAndroidTools.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w(&a);
    w.show();
    //w.showFullScreen();
    return a.exec();


    /*QQuickView view;
    view.setSource(QUrl::fromLocalFile(":/qml/interface/banner_test.qml"));
    view.setWidth(320);
    view.setHeight(50);
    QObject *object = (QObject*)view.rootObject();
    object->setProperty("width", 320);
    object->setProperty("height", 50);
    //QObject *banner1 = object->findChild<QObject*>("col")->findChild<QObject*>("rect")->findChild<QObject*>("banner1");
    QMetaObject::invokeMethod(object, "show");*/
    //view.showNormal();
}
