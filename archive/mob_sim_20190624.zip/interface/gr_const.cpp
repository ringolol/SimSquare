#include "gr_const.h"

int GRID_STEP0=25;
int GRID_STEP=GRID_STEP0;

int GRID_OFFSET_X=0;
int GRID_OFFSET_Y=0;

double dpi=10;
