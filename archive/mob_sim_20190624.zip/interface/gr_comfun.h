#ifndef GR_COMFUN_H
#define GR_COMFUN_H

#include "gr_const.h"

int GridFit(double xx);

double sign(double xx);

double Get1cm();

#endif // GR_COMFUN_H
