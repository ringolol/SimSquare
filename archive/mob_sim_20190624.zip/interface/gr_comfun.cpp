#include "gr_comfun.h"

int GridFit(double xx)
{
    return ((int)(xx*1.0/GRID_STEP+0.5));
}

double sign(double xx)
{
    return xx>=0?1:-1;
}

double Get1cm()
{
    // 0.4 = 1/2.54
    return 0.4*dpi;
}




