#include "gr_mainwin.h"


MainWindow::MainWindow()
{
    //Show overlay
    //InfOverlay=true;

    //android
    #if defined(Q_OS_ANDROID)
    QAndroidJniObject activity=QtAndroid::androidActivity();
    QAndroidJniObject context=QtAndroid::androidContext();
    QAndroidJniObject str_dir = QAndroidJniObject::fromString("");
    QAndroidJniObject AppDirJni = activity.callObjectMethod("getExternalFilesDir", "(Ljava/lang/String;)Ljava/io/File;",str_dir.object<jstring>());
    if(AppDirJni.toString() == QString(""))
        AppDirJni=activity.callObjectMethod("getFilesDir", "()Ljava/io/File;");
    AppDir=AppDirJni.toString();
    //set attr
    setAttribute(Qt::WA_AcceptTouchEvents, true);
    //grab gesture
    this->grabGesture(Qt::GestureType::PinchGesture);
    #else
    AppDir=QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    #endif
    AppDir+='/';

    //set up vibration
    SetVibrator();

    //set window pars
    SetWindow();

    //Update screen size
    UpdSizeInf();

    //set grid
    SetGrid();

    //load widndows/panels/blocks/buttons
    LoadContent();

    //create pens fonts etc.
    SetPainters();

    //set screen refresh timer
    SetMainTimer();

    //set up dbl clk timer
    SetDblClkTimer();

    //set tap and hold timer
    SetTapHoldTimer();

    //graph update timer
    graphUpd= new QTimer(this);
    connect(graphUpd, &QTimer::timeout, this, &MainWindow::PrepareGra);
}

MainWindow::MainWindow(QApplication *a) : MainWindow()
{
    ThisApp=a;
    connect(a,SIGNAL(applicationStateChanged(Qt::ApplicationState)),this,SLOT(AppStateEv(Qt::ApplicationState)));
    connect(a,SIGNAL(aboutToQuit()),this,SLOT(AboutToQuit()));
}

MainWindow::~MainWindow()
{
    CoreThread.exit();
    CoreThread.wait();
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    //draw preparation
    painter.begin(this);

    //set default pens/brushes/fonts and render options
    SetDrawInstr();

    //draw things
    Draw(event);

    //end painting
    painter.end();
}

void MainWindow::Draw(QPaintEvent *event)
{
    //upd
    UpdSizeInf();
    Windows[ActiveWin]->Upd(w_w,w_h);

    //draw BG
    painter.fillRect(event->rect(), bgBrush);

    //draw workspace
    if(ActiveWin==WI_WS)
        DrawWorkSpace(event);

    //draw GUI
    Windows[ActiveWin]->Draw(&painter,event);

    //draw information overlay
    DrawInf(event);
}

void MainWindow::DrawWorkSpace(QPaintEvent *event)
{
    //draw grid
    DrawGrid(event);

    //draw objects
    DrawObjects(event);

    //draw lines
    DrawLines(event);
}

void MainWindow::SetWindow()
{
    QScreen *screen = QApplication::screens().at(0);
    resize(screen->availableSize().width(),screen->availableSize().height());
}

void MainWindow::SetDrawInstr()
{
    //set default instruments
    painter.setPen(mainPen);
    painter.setFont(mainFont);
    //set render hints
    painter.setRenderHint(QPainter::Antialiasing);
}

void MainWindow::SetPainters()
{
    //backgroud color
    bgBrush = QBrush(QColor(255, 255, 255));
    //main pen
    mainPen = QPen(Qt::black);
    mainPen.setWidth(1);
    //grid pen
    gridPen=QPen(Qt::lightGray);
    gridPen.setWidth(1);
    //line pen
    linePen=QPen(Qt::black);
    linePen.setWidth((int)(0.1*Get1cm()+0.5));
    //linePen.setWidth(3);
    //main text font
    mainFont.setPixelSize(12);
}

void MainWindow::SetMainTimer()
{
    //set and start the main timer
    mainTimer= new QTimer(this);
    connect(mainTimer, &QTimer::timeout, this, &MainWindow::Anima);
    mainTimer->start(MAIN_TIMER_UPD_TIME);
}

void MainWindow::UpdSizeInf()
{
    QScreen *screen = QApplication::screens().at(0);
    w_w=size().width();
    w_h=size().height();
    dpi=screen->logicalDotsPerInch();
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    //call original event
    QOpenGLWidget::resizeEvent(event);
    //reset graph
    Graph->isPrepared=false;
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_Back)
    {
        switch (ActiveWin)
        {
        case WI_WS:
            ActiveWin=WI_MAIN;
            break;
        case WI_MAIN:
            ThisApp->exit();
            break;
        case WI_AB:
            ActiveWin=WI_BT;
            break;
        case WI_GR:
            ActiveWin=WI_WS;
            break;
        case WI_BT:
            ActiveWin=WI_WS;
            break;
        }
        event->accept();
    }
}

void MainWindow::Anima()
{
    //drag
    if(isDrag)
    {
        Drawables[drag_ind]->SetX(mX+drag_offset_X);
        Drawables[drag_ind]->SetY(mY+drag_offset_Y);
    }

    //update grid offset
    if(isOffset)
    {
        grid_offset_smoth_X+=mX-Xoff1;
        grid_offset_smoth_Y+=mY-Yoff1;
        UpdGrid();
        Xoff1=mX;
        Yoff1=mY;
    }

    //check if user start drag object
    if(isHold && sqrt((mX-mX0)*(mX-mX0)+(mY-mY0)*(mY-mY0))>Get1cm()*SMALL_AREA)
    {
        //Drawables[ind_pressed]->wasClicked=false;
        //if they started than
        tapHoldTimer->stop();
        ClearHL();
        isHold=false;
        ModifyObject(NULL,ind_pressed,3);
    }

    //check if user start scrolling
    if(may_scroll)
    {
        if(!scroll && sqrt((mX-mX0)*(mX-mX0)+(mY-mY0)*(mY-mY0))>Get1cm()*SMALL_AREA)
        {
            Yscr=mY;
            scroll=true;
        }
    }
    //animate scrolling
    if(scroll)
    {
        int dy=mY-Yscr;
        int yn=Windows[ActiveWin]->Panels[clk.first]->y+dy;
        if((dy>0 && yn<Windows[ActiveWin]->Panels[clk.first]->y0) || (dy<0 && yn+Windows[ActiveWin]->Panels[clk.first]->height>w_h))
        {
            Windows[ActiveWin]->Panels[clk.first]->y+=dy;
        }
        Yscr=mY;
    }

    //redraw window (call paintEvent)
    update();
}

void MainWindow::SetGrid()
{
    GRID_STEP0=(int)(Get1cm()*0.75+0.5);
    GRID_STEP=GRID_STEP0;
    GRID_OFFSET_X=0;
    GRID_OFFSET_Y=0;
    grid_step_smooth=GRID_STEP0;
    grid_offset_smoth_X=GRID_OFFSET_X;
    grid_offset_smoth_Y=GRID_OFFSET_Y;
}

void MainWindow::SetDblClkTimer()
{
    doubleClkTimer = new QTimer(this);
    doubleClkTimer->setSingleShot(true);
    connect(doubleClkTimer, &QTimer::timeout, this, &MainWindow::NotDoubleClk);
}

void MainWindow::SetTapHoldTimer()
{
    tapHoldTimer = new QTimer(this);
    tapHoldTimer->setSingleShot(true);
    connect(tapHoldTimer, &QTimer::timeout, this, &MainWindow::TapAndHoldEv);
}

void MainWindow::SetVibrator()
{
    #if defined(Q_OS_ANDROID)
    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty("Vibrator", &vibrator);
    #endif
}

void MainWindow::DrawInf(QPaintEvent *event)
{
    if(!InfOverlay)
        return;

    //set Pen
    QFont ov_font;
    ov_font.setPixelSize((int)(0.5*Get1cm()+0.5));
    painter.setFont(ov_font);
    //create string
    QString str=QString("\nmX=")+QString::number(mX)\
            +QString(";   mY=")+QString::number(mY)\
            +QString("\nWinW=")+QString::number(this->width())\
            +QString("   WinH=")+QString::number(this->height())\
            +QString("\nGRID_STEP=")+QString::number(grid_step_smooth)\
            +QString("\nGRID_X=")+QString::number(grid_offset_smoth_X)\
            +QString(";   GRID_Y=")+QString::number(grid_offset_smoth_X)\
            +"\ndir=\""+AppDir+"\""\
            +"\nfile_name=\""+file_name+"\""\
            +QString("\nCheck Point=")+QString::number(testCheckpoint)+\
            testStr +'\n';
    //draw overlay
    painter.drawText(QRect(0, 0, w_w, w_h), Qt::AlignLeft,str);
}

void MainWindow::DrawObjects(QPaintEvent *event)
{
    painter.setPen(linePen);
    for(int i=0;i<Drawables.size();i++)
    {
            Drawables[i]->Draw(&painter,event);
    }
}

void MainWindow::DrawLines(QPaintEvent *event)
{
    painter.setPen(linePen);

    for(int i=0;i<Lines.size();i++)
    {
        Lines[i]->Draw(&painter,event);
    }
}

void MainWindow::DrawGrid(QPaintEvent *event)
{
    //set pen
    painter.setPen(gridPen);
    //draw vertical lines
    int x_off=GRID_OFFSET_X%GRID_STEP;
    int y_off=GRID_OFFSET_Y%GRID_STEP;
    for (int i=0;i<event->rect().width();i++)
    {
        painter.drawLine(i*GRID_STEP+x_off,0,i*GRID_STEP+x_off,event->rect().height());
    }
    //draw horizontal lines
    for (int j=0;j<event->rect().height();j++)
    {
        painter.drawLine(0,j*GRID_STEP+y_off,event->rect().width(),j*GRID_STEP+y_off);
    }
}

//Mouse
void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    MouMoveEv(event->x(),event->y());
}

void MainWindow::CopyByDragging(QMouseEvent *event, int i)
{
    //create new item
    Gr_DrawCore *dr=new Gr_DrawCore(Drawables[i]);
    //set workspace-type
    dr->SetType(DRWABLE_WORKSPACE);
    //set calc index
    dr->calcInd=GetCalcInd();
    //add element to drawables
    Drawables.push_back(dr);
    //set drag options
    drag_ind=Drawables.size()-1;
    isDrag=1;
    drag_offset_X=Drawables[i]->GetX()-mX-GRID_OFFSET_X;
    drag_offset_Y=Drawables[i]->GetY()-mY-GRID_OFFSET_Y;
}

void MainWindow::WorkSpaceClick()
{
    //else offset grid
    Xoff1=mX;
    Yoff1=mY;
    isOffset=true;
}

void MainWindow::ModifyObject(QMouseEvent *event, int i,int force_CT)
{
    if(i==-1)
    {
        qDebug()<<"ERROR: Obj Click incorrect Index"<<endl;
        return;
    }

    //force cursor type
    int c_type=cursor_type;
    if(force_CT!=-1)
        c_type=force_CT;

    switch (c_type)
    {
    case 0:
        int InpCl;
        int OutCl;
        //input clicked?
        if((InpCl=Drawables[i]->InputClicked(mX,mY))!=-1)
        {
            if(line_indIn==i && line_numIn==InpCl)
                DotInExist=!DotInExist;
            else
                DotInExist=true;

            line_indIn=i;
            line_numIn=InpCl;

            //HL HERE
            //Drawables[line_indIn]->SetHL(DotInExist?1:0,line_numIn);
        }
        //output clicked?
        if((OutCl=Drawables[i]->OutputClicked(mX,mY))!=-1)
        {
            if(line_indOut==i && line_numOut==OutCl)
                DotOutExist=!DotOutExist;
            else
                DotOutExist=true;

            line_indOut=i;
            line_numOut=OutCl;

            //HL HERE
            //Drawables[line_indOut]->SetHL(DotOutExist?2:0,line_numOut);
        }
        //create line between input and output if both flags are set
        if(DotInExist && DotOutExist)
        {
            Gr_Line* linet=new Gr_Line();
            linet->SetPi(Drawables[line_indIn],line_numIn);
            linet->SetPo(Drawables[line_indOut],line_numOut);
            Lines.push_back(linet);
            Drawables[line_indIn]->ResetHL();
            Drawables[line_indOut]->ResetHL();
            DotInExist=false;
            DotOutExist=false;
        }
        break;
    case 1:
        //rotate block
        Drawables[i]->Rotate();
        break;
    case 2:
        if(Drawables[i]->GetType()==DRWABLE_WORKSPACE)
        {
            //if graph was clicked
            if(Gr_Core::GetMode(Drawables[i]->core_type)==COM_SCOPE)
            {
                //vibrate
                #if defined(Q_OS_ANDROID)
                vibrator.vibrate(VIBRATE_TIME);
                #endif

                //prepare graph
                Graph->SetData(&Drawables[i]->data);
                Graph->Prepare();
                if(CoreThread.isRunning())
                {
                    graphUpd->start(GRAPH_UPD_TIME);
                }
                //pop-up graph
                ActiveWin=WI_GR;
            }
            //if other block was clicked
            else
            {
                //if modal wasn't shown don't vibrate
                if(!SetSAndP(Drawables[i]))
                    return;
            }
        }
        break;
    case 3:
        //set and start dragging workspace
        drag_ind=i;
        isDrag=2;
        drag_offset_X=Drawables[i]->GetX()-mX-GRID_OFFSET_X;
        drag_offset_Y=Drawables[i]->GetY()-mY-GRID_OFFSET_Y;
        break;
    }
}

void MainWindow::ButtonClick(QMouseEvent *event, Gr_Drawable *o)
{
    if(ActiveWin==WI_WS)
    {
        switch (o->event)
        {
        case DE_SIM:
            StartCalc();
            break;
        case DE_ADD:
            ActiveWin=WI_BT;
            break;
        case DE_MOVE:
            cursor_type=0;
            break;
        case DE_DELETE:
            DeleteObjs();
            break;
        case DE_SHOWALL:
            break;
        case DE_BACK:
            ActiveWin=WI_MAIN;
        }
    }
    else if(ActiveWin==WI_BT)
    {
        if(o->event==DE_BT_BACK)
        {
            ActiveWin=WI_WS;
        }
        else
        {
            ActiveWin=WI_AB;
            for(int i=1;i<Windows[ActiveWin]->Panels.size();i++)
            {
                Windows[ActiveWin]->Panels[i]->isDrawn=false;
            }

            int ind=-1;
            switch (o->event)
            {
            case DE_BT_COMMON:
                ind=1;
                break;
            case DE_BT_SOURCE:
                ind=2;
                break;
            case DE_BT_MATH:
                ind=5;
                break;
            case DE_BT_LINE:
                ind=6;
                break;
            case DE_BT_SCOPE:
                ind=3;
                break;
            case DE_BT_NONLINE:
                ind=7;
                break;
            case DE_BT_LOGIC:
                ind=4;
                break;
            }

            if(ind>0)
                Windows[ActiveWin]->Panels[ind]->isDrawn=true;

        }
    }
    else if(ActiveWin==WI_AB)
    {
        if(o->event==DE_AB_BACK)
        {
            ActiveWin=WI_BT;
            return;
        }
        else
            AddBlock(((Gr_DrawCore*)o)->core_type);

        ActiveWin=WI_WS;
    }
    else if(ActiveWin==WI_MAIN)
    {
        switch (o->event)
        {
        case DE_MW_NEW:
            Clear();
            if(Save(true))
                ActiveWin=WI_WS;
            break;
        case DE_MW_LOAD:
            Save();
            if(Load())
                ActiveWin=WI_WS;
            break;
        case DE_MW_REPORT:
            break;
        }
    }
}

void MainWindow::WorkspaceObjClick(QMouseEvent *event)
{
    for(int i=Drawables.size()-1;i>=0;i--)
    {
        //if the i-th element is clicked
        if(Drawables[i]->Clicked(mX,mY))
        {
            switch(Drawables[i]->GetType())
            {
            //worckspace items handler
            case DRWABLE_WORKSPACE:
                //set options to handle click(on release) or hold events
                //mem index
                ind_pressed=i;
                //set flag (if !isHold than Drag or Tap&Hold ev)
                isHold=true;

                if(cursor_type==0 && isBodyClick(i))
                {
                    //set double clk flag
                    if(DoubleClkFlg && RotateInd==i)
                    {
                        DblRotate=true;
                    }
                    else
                    {
                        //start double clk
                        RotateInd=i;
                        DoubleClkFlg=true;
                        //set HL
                        //ClearHL();
                        Drawables[ind_pressed]->wasClicked=!Drawables[ind_pressed]->wasClicked;
                        //start timer
                        doubleClkTimer->start(DBL_CLK_TIME);
                    }
                    //start Tap&Hold timer
                    tapHoldTimer->start(TAP_AND_HOLD_TIME);
                }
                break;
            }
            return;
        }
    }
    //else offset grid
    if(cursor_type==0)
        WorkSpaceClick();
}

bool MainWindow::event(QEvent *event)
{
    //if gesture
    if(event->type()==QEvent::Gesture)
    {
        QGestureEvent *ev=(QGestureEvent*)event;
        //if gesture is pinch
        if(QPinchGesture *pinch=(QPinchGesture*)ev->gesture(Qt::PinchGesture))
        {
            double sc=pinch->scaleFactor();
            if(sc>=1)
                sc=1+(sc-1)/ZOOM_GAIN;
            else
                sc=1/(1+(1/sc-1)/ZOOM_GAIN);

            ZoomEv(pinch->centerPoint().x(),pinch->centerPoint().y(),sc);
        }
        ResetFlags();
        return true;
    }
    //accept new gestures
    else  if(event->type() == QEvent::GestureOverride)
    {
        event->accept();
    }
    //tap events
    else if(event->type() == QEvent::TouchBegin || event->type() == QEvent::TouchEnd || event->type() == QEvent::TouchCancel || event->type()==QEvent::TouchUpdate)
    {
        QTouchEvent *ev=(QTouchEvent*)event;

        if(ev->touchPoints().size()==0) return true;

        int px=ev->touchPoints()[0].lastPos().x();
        int py=ev->touchPoints()[0].lastPos().y();

        //pressed event
        if(ev->touchPoints()[0].state()==Qt::TouchPointState::TouchPointPressed)
        {
            MouPressEv(px,py);
        }
        //release event
        else if (ev->touchPoints()[0].state()==Qt::TouchPointState::TouchPointReleased)
        {
            MouReleaseEv(px,py);
        }
        //moved event
        else if(ev->touchPoints()[0].state()==Qt::TouchPointState::TouchPointMoved)
        {
            MouMoveEv(px,py);
        }
        return true;
    }
    return QOpenGLWidget::event(event);
}

void MainWindow::TapAndHoldEv()
{
    ClearHL();
    ResetDblClk();
    ModifyObject(NULL,ind_pressed,2);
    ResetFlags();
}

void MainWindow::NotDoubleClk()
{
    //HL HERE
    ResetDblClk();
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    MouPressEv(event->x(),event->y());
}

void MainWindow::MouPressEv(int px,int py)
{
    //update mouse position
    mX=px;
    mY=py;

    //mem original position
    mX0=mX;
    mY0=mY;

    //reset mouse flags and vars
    ResetFlags();

    //check panel click
    clk=Windows[ActiveWin]->ObjClicked(mX,mY);

    //if any panel was clicked
    if(clk.first!=-1)
    {
        if(Windows[ActiveWin]->Panels[clk.first]->resize_cont)
        {
            //can be scrolled
            may_scroll=true;
        }
        return;
    }

    //if click was on the work zone
    switch(ActiveWin)
    {
    //workspace window
    case WI_WS:
        WorkspaceObjClick(NULL);
        break;
    //graph window
    case WI_GR:
        graphUpd->stop();
        ActiveWin=WI_WS;
        break;
    }
}

void MainWindow::MouMoveEv(int px,int py)
{
    //update mouse position information
    mX=px;
    mY=py;
}

void MainWindow::MouReleaseEv(int px,int py)
{
    //update m pos
    mX=px;
    mY=py;

    //double click
    if(DblRotate)
    {
        ClearHL();
        ModifyObject(NULL,RotateInd,1);
        ResetDblClk();
    }

    //click object
    if(isHold)
    {
        ModifyObject(NULL,ind_pressed);
    }

    //press btn on panel
    if(!scroll && clk.second!=-1)
    {
        //handle event
        ButtonClick(NULL,Windows[ActiveWin]->Panels[clk.first]->Objects[clk.second]);
    }

    //reset mouse flags
    ResetFlags();
}

void MainWindow::ZoomEv(int px,int py,double sc)
{
    if(ActiveWin==WI_WS)
    {
        //zoom in/out on cursor position (workspace)
        double grid_s_new;
        grid_s_new=grid_step_smooth*sc;
        grid_s_new=grid_s_new>1.0?grid_s_new:1.0;

        grid_offset_smoth_X=(grid_offset_smoth_X)*(grid_s_new/grid_step_smooth)+px-px*(grid_s_new/grid_step_smooth);
        grid_offset_smoth_Y=(grid_offset_smoth_Y)*(grid_s_new/grid_step_smooth)+py-py*(grid_s_new/grid_step_smooth);
        grid_step_smooth=grid_s_new;

        UpdGrid();
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
    MouReleaseEv(event->x(),event->y());
}

void MainWindow::wheelEvent(QWheelEvent *event)
{
    ZoomEv(event->x(),event->y(),1+0.1*sign(event->angleDelta().y()));
}

void MainWindow::LoadContent()
{
    //create windows
    //workspace
    //forse rescale by setting width-1
    Gr_Window *gui_ws=new Gr_Window(0,0,w_w-1,w_h,DRWABLE_STATIC);
    //block type
    Gr_Window *gui_bt=new Gr_Window(0,0,w_w-1,w_h,DRWABLE_STATIC);
    //add block
    Gr_Window *gui_ab=new Gr_Window(0,0,w_w-1,w_h,DRWABLE_STATIC);
    //graph
    Graph=new Gr_Graph(0,0,w_w-1,w_h,DRWABLE_GRAPH);
    //main
    Gr_Window *gui_main=new Gr_Window(0,0,w_w-1,w_h,DRWABLE_STATIC);
    Windows.insert(pair<window_index,Gr_Window*>(WI_WS,gui_ws));
    Windows.insert(pair<window_index,Gr_Window*>(WI_BT,gui_bt));
    Windows.insert(pair<window_index,Gr_Window*>(WI_AB,gui_ab));
    Windows.insert(pair<window_index,Gr_Window*>(WI_GR,Graph));
    Windows.insert(pair<window_index,Gr_Window*>(WI_MAIN,gui_main));

    //WORKSPACE WINDOW
    //toolbar
    Gr_Panel *p1=new Gr_Panel(w_w-Get1cm()*5,0,Get1cm()*5,Get1cm()*1.5);
    p1->right=true;
    p1->top=true;
    p1->LoadImg(":/images/toolbar/pic/toolbar_bg.png");
    Windows[WI_WS]->Panels.push_back(p1);
    //move btn
    //Gr_Drawable *move_btn=new Gr_Drawable(Get1cm()*0.25,Get1cm()*0.25,Get1cm(),Get1cm(),DRWABLE_BUTTON,DE_MOVE);
    //move_btn->LoadImg(":/images/toolbar/pic/move_btn.png");
    //Windows[WI_WS]->Panels[0]->Objects.push_back(move_btn);
    //sim button
    Gr_Drawable *sim_btn=new Gr_Drawable(Get1cm()*0.5,Get1cm()*0.25,Get1cm(),Get1cm(),DRWABLE_BUTTON,DE_SIM);
    sim_btn->LoadImg(":/images/elements/pic/butt_sim.png");
    Windows[WI_WS]->Panels[0]->Objects.push_back(sim_btn);
    //show all
    Gr_Drawable *showall_btn=new Gr_Drawable(Get1cm()*2,Get1cm()*0.25,Get1cm(),Get1cm(),DRWABLE_BUTTON,DE_SHOWALL);
    showall_btn->LoadImg(":/images/toolbar/pic/showall_btn.png");
    Windows[WI_WS]->Panels[0]->Objects.push_back(showall_btn);
    //delete btn
    Gr_Drawable *delete_btn=new Gr_Drawable(Get1cm()*3.5,Get1cm()*0.25,Get1cm(),Get1cm(),DRWABLE_BUTTON,DE_DELETE);
    delete_btn->LoadImg(":/images/toolbar/pic/delete_btn.png");
    Windows[WI_WS]->Panels[0]->Objects.push_back(delete_btn);


    //back panel
    Gr_Panel *p2=new Gr_Panel(0,0,Get1cm()*1.5,Get1cm()*1.5);
    p2->left=true;
    p2->top=true;
    p2->LoadImg(":/images/toolbar/pic/arrow_bg.png");
    Windows[WI_WS]->Panels.push_back(p2);
    //back btn
    Gr_Drawable *back_btn=new Gr_Drawable(0,0,Get1cm()*1.5,Get1cm()*1.5,DRWABLE_BUTTON,DE_BACK);
    back_btn->LoadImg(":/images/toolbar/pic/back_btn.png");
    Windows[WI_WS]->Panels[1]->Objects.push_back(back_btn);

    //add panel
    Gr_Panel *p3=new Gr_Panel(w_w-Get1cm()*1.75,w_h-Get1cm()*1.75,Get1cm()*1.75,Get1cm()*1.75);
    p3->right=true;
    p3->bottom=true;
    Windows[WI_WS]->Panels.push_back(p3);
    //add button
    Gr_Drawable *add_btn=new Gr_Drawable(0,0,Get1cm()*1.5,Get1cm()*1.5,DRWABLE_BUTTON,DE_ADD);
    add_btn->LoadImg(":/images/toolbar/pic/btn_add.png");
    Windows[WI_WS]->Panels[2]->Objects.push_back(add_btn);


    //BLOCKTYPE WINDOW
    //title
    Gr_Panel *pb1=new Gr_Panel(0,0,w_w,Get1cm()*1.5);
    pb1->left=true;
    pb1->top=true;
    pb1->LoadImg(":/images/other/pic/menu_bg.png");
    pb1->static_w=false;
    Windows[WI_BT]->Panels.push_back(pb1);
    //back btn
    Gr_Drawable *bt_back_btn=new Gr_Drawable(0,0,Get1cm()*1.5,Get1cm()*1.5,DRWABLE_BUTTON,DE_BT_BACK);
    bt_back_btn->LoadImg(":/images/toolbar/pic/back_btn.png");
    Windows[WI_BT]->Panels[0]->Objects.push_back(bt_back_btn);

    //content
    Gr_Panel *pb2=new Gr_Panel(0,Get1cm()*1.5,w_w,w_h-Get1cm()*1.5);
    pb2->left=true;
    pb2->top=true;
    pb2->resize_cont=true;
    pb2->static_h=false;
    pb2->static_w=false;
    Windows[WI_BT]->Panels.push_back(pb2);

    Gr_Drawable *c0=new Gr_Drawable(0,0,634,261,DRWABLE_BUTTON,DE_BT_COMMON);
    c0->LoadImg(":/images/toolbar/pic/tb_common.png");
    Windows[WI_BT]->Panels[1]->Objects.push_back(c0);

    Gr_Drawable *c1=new Gr_Drawable(0,0,634,261,DRWABLE_BUTTON,DE_BT_SOURCE);
    c1->LoadImg(":/images/toolbar/pic/tb_source.png");
    Windows[WI_BT]->Panels[1]->Objects.push_back(c1);

    Gr_Drawable *c2=new Gr_Drawable(0,0,634,261,DRWABLE_BUTTON,DE_BT_MATH);
    c2->LoadImg(":/images/toolbar/pic/tb_arithmetic.png");
    Windows[WI_BT]->Panels[1]->Objects.push_back(c2);

    Gr_Drawable *c3=new Gr_Drawable(0,0,634,261,DRWABLE_BUTTON,DE_BT_LINE);
    c3->LoadImg(":/images/toolbar/pic/tb_linear.png");
    Windows[WI_BT]->Panels[1]->Objects.push_back(c3);

    Gr_Drawable *c4=new Gr_Drawable(0,0,634,261,DRWABLE_BUTTON,DE_BT_SCOPE);
    c4->LoadImg(":/images/toolbar/pic/tb_scope.png");
    Windows[WI_BT]->Panels[1]->Objects.push_back(c4);

    Gr_Drawable *c5=new Gr_Drawable(0,0,634,261,DRWABLE_BUTTON,DE_BT_NONLINE);
    c5->LoadImg(":/images/toolbar/pic/tb_nonlinear.png");
    Windows[WI_BT]->Panels[1]->Objects.push_back(c5);

    Gr_Drawable *c6=new Gr_Drawable(0,0,634,261,DRWABLE_BUTTON,DE_BT_LOGIC);
    c6->LoadImg(":/images/toolbar/pic/tb_logic.png");
    Windows[WI_BT]->Panels[1]->Objects.push_back(c6);

    //COMMON BLOCK ADD
    //title
    Gr_Panel *pa1=new Gr_Panel(0,0,w_w,Get1cm()*1.5);
    pa1->left=true;
    pa1->top=true;
    pa1->LoadImg(":/images/other/pic/menu_bg.png");
    pa1->static_w=false;
    Windows[WI_AB]->Panels.push_back(pa1);
    //back btn
    Gr_Drawable *ab_back_btn=new Gr_Drawable(0,0,Get1cm()*1.5,Get1cm()*1.5,DRWABLE_BUTTON,DE_AB_BACK);
    ab_back_btn->LoadImg(":/images/toolbar/pic/back_btn.png");
    Windows[WI_AB]->Panels[0]->Objects.push_back(ab_back_btn);

    //content
    Gr_Panel *p_fav=new Gr_Panel(0,Get1cm()*1.5,w_w,w_h-Get1cm()*1.5);
    p_fav->SetScalable();

    //FAV PAN
    core_obj_types ct;
    int n_in,n_out;
    Gr_DrawCore *o=NULL;
    //... fav bloks
    Windows[WI_AB]->Panels.push_back(p_fav);

    //SOURCE PAN
    Gr_Panel *p_source=new Gr_Panel(0,Get1cm()*1.5,w_w,w_h-Get1cm()*1.5);
    p_source->SetScalable();
    for(int i=COT_SOURCE;i<=COT_TIME;i++)
    {
        ct=(core_obj_types)i;
        o=new Gr_DrawCore(0,0,Gr_Core::NumOfInputs(ct),Gr_Core::NumOfOutputs(ct),DRWABLE_TOOLS,ct);
        o->isStatic=true;
        LoadImg(o);
        p_source->Objects.push_back(o);
    }
    Windows[WI_AB]->Panels.push_back(p_source);

    //SCOPE PAN
    Gr_Panel *p_scp=new Gr_Panel(0,Get1cm()*1.5,w_w,w_h-Get1cm()*1.5);
    p_scp->SetScalable();
    for(int i=COT_SCP;i<=COT_SCP_4PLOTS;i++)
    {
        ct=(core_obj_types)i;
        o=new Gr_DrawCore(0,0,Gr_Core::NumOfInputs(ct),Gr_Core::NumOfOutputs(ct),DRWABLE_TOOLS,ct);
        o->isStatic=true;
        LoadImg(o);
        p_scp->Objects.push_back(o);
    }
    Windows[WI_AB]->Panels.push_back(p_scp);

    //LOGIC PAN
    Gr_Panel *p_log=new Gr_Panel(0,Get1cm()*1.5,w_w,w_h-Get1cm()*1.5);
    p_log->SetScalable();
    for(int i=COT_S0;i<=COT_RSTRIGGER;i++)
    {
        ct=(core_obj_types)i;
        o=new Gr_DrawCore(0,0,Gr_Core::NumOfInputs(ct),Gr_Core::NumOfOutputs(ct),DRWABLE_TOOLS,ct);
        o->isStatic=true;
        LoadImg(o);
        p_log->Objects.push_back(o);
    }
    Windows[WI_AB]->Panels.push_back(p_log);

    //MATH PAN
    Gr_Panel *p_math=new Gr_Panel(0,Get1cm()*1.5,w_w,w_h-Get1cm()*1.5);
    p_math->SetScalable();
    for(int i=COT_ADD;i<=COT_LN;i++)
    {
        ct=(core_obj_types)i;
        o=new Gr_DrawCore(0,0,Gr_Core::NumOfInputs(ct),Gr_Core::NumOfOutputs(ct),DRWABLE_TOOLS,ct);
        o->isStatic=true;
        LoadImg(o);
        p_math->Objects.push_back(o);
    }
    Windows[WI_AB]->Panels.push_back(p_math);

    //LINEAR PAN
    Gr_Panel *p_line=new Gr_Panel(0,Get1cm()*1.5,w_w,w_h-Get1cm()*1.5);
    p_line->SetScalable();
    for(int i=COT_INTEG;i<=COT_HARMONIC;i++)
    {
        ct=(core_obj_types)i;
        o=new Gr_DrawCore(0,0,Gr_Core::NumOfInputs(ct),Gr_Core::NumOfOutputs(ct),DRWABLE_TOOLS,ct);
        o->isStatic=true;
        LoadImg(o);
        p_line->Objects.push_back(o);
    }
    Windows[WI_AB]->Panels.push_back(p_line);

    //NON-LINEAR PAN
    Gr_Panel *p_nonline=new Gr_Panel(0,Get1cm()*1.5,w_w,w_h-Get1cm()*1.5);
    p_nonline->SetScalable();
    for(int i=COT_BACKLASH;i<=COT_DEADZONE;i++)
    {
        ct=(core_obj_types)i;
        o=new Gr_DrawCore(0,0,Gr_Core::NumOfInputs(ct),Gr_Core::NumOfOutputs(ct),DRWABLE_TOOLS,ct);
        o->isStatic=true;
        LoadImg(o);
        p_nonline->Objects.push_back(o);
    }
    Windows[WI_AB]->Panels.push_back(p_nonline);

    //MAIN WIN
    Gr_Panel *p_main_btns=new Gr_Panel(0,0,Get1cm()*8,Get1cm()*8);
    p_main_btns->mid_vert=true;
    p_main_btns->mid_horiz=true;
    Gr_Drawable *main_btn1=new Gr_Drawable(Get1cm()*0.5,Get1cm()*0.5,7*Get1cm(),2*Get1cm(),DRWABLE_STATIC,DE_MW_NEW);
    Gr_Drawable *main_btn2=new Gr_Drawable(Get1cm()*0.5,Get1cm()*3,7*Get1cm(),2*Get1cm(),DRWABLE_STATIC,DE_MW_LOAD);
    Gr_Drawable *main_btn3=new Gr_Drawable(Get1cm()*0.5,Get1cm()*5.5,7*Get1cm(),2*Get1cm(),DRWABLE_STATIC,DE_MW_REPORT);
    main_btn1->DrawBorder=true;
    main_btn2->DrawBorder=true;
    main_btn3->DrawBorder=true;
    p_main_btns->DrawBorder=true;
    p_main_btns->Objects.push_back(main_btn1);
    p_main_btns->Objects.push_back(main_btn2);
    p_main_btns->Objects.push_back(main_btn3);
    Windows[WI_MAIN]->Panels.push_back(p_main_btns);
}

//convert from interface to core
void MainWindow::Convert()
{
    //create new core object
    delete core;
    core=new Gr_Core;
    //for each workspace element create core-object with core-index
    for(int i=0;i<Drawables.size();i++)
    {
        if(Drawables[i]->GetType()==DRWABLE_WORKSPACE)
            core->Add(Drawables[i]->core_type,Drawables[i]->inpN,Drawables[i]->outpN,Drawables[i]->pars,Drawables[i]->states,&Drawables[i]->data);
    }
    //transform lines information into core-links
    for(int i=0;i<Lines.size();i++)
    {
        core->Link(Lines[i]->in_obj->calcInd,Lines[i]->numIn,Lines[i]->out_obj->calcInd,Lines[i]->numOut);
    }
}

//calculate core
void MainWindow::Calc()
{
    //calc thread
    core->moveToThread(&CoreThread);
    connect(this, SIGNAL(calc_sign(double)), core, SLOT(Calc(double)));
    connect(core, SIGNAL(calc_fin()), this, SLOT(StopThread()));

    CoreThread.start();

    if(core!=NULL)
    {
        //set sim step
        core->SetStep(Ssim);
        //start calc in new thread
        emit calc_sign(Tsim);
        //redraw graph
        //Graph->Prepare();
    }
    else
    {
        qDebug()<<"ERROR: Can't Calc no core object"<<endl;
    }
}

int MainWindow::GetCalcInd()
{
    //first return and than increment calcInd
    return calcInd++;
}

bool MainWindow::GetSimData()
{
    //creatin a form
    QDialog dialog(this);
    QFormLayout form(&dialog);
    QList<QLineEdit *> fields_par;
    QLineEdit *lineEdit1 = new QLineEdit(&dialog);
    lineEdit1->setInputMethodHints(Qt::ImhPreferNumbers);
    lineEdit1->setValidator( new QDoubleValidator() );
    lineEdit1->setText(QString::number(Tsim));

    QString label1 = QString("Sim Time");
    form.addRow(label1, lineEdit1);
    fields_par << lineEdit1;

    QLineEdit *lineEdit2 = new QLineEdit(&dialog);
    lineEdit2->setInputMethodHints(Qt::ImhPreferNumbers);
    lineEdit2->setValidator( new QDoubleValidator() );
    lineEdit2->setText(QString::number(Ssim));
    QString label2 = QString("Sim Step");
    form.addRow(label2, lineEdit2);
    fields_par << lineEdit2;

    QDialogButtonBox buttonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel,
                               Qt::Horizontal, &dialog);
    form.addRow(&buttonBox);
    QObject::connect(&buttonBox, SIGNAL(accepted()), &dialog, SLOT(accept()));
    QObject::connect(&buttonBox, SIGNAL(rejected()), &dialog, SLOT(reject()));

    //show keyboard on dial.show
    dialog.show();
    lineEdit1->setFocus();
    lineEdit1->selectAll();
    QInputMethod *keyboard = QGuiApplication::inputMethod();
    keyboard->show();

    //if Ok was clicked
    if (dialog.exec() == QDialog::Accepted)
    {
        Tsim=fields_par[0]->text().replace(',','.').toDouble();
        Ssim=fields_par[1]->text().replace(',','.').toDouble();
        return true;
    }
    return false;
}

bool MainWindow::Save(bool PopFlg)
{
    if(PopFlg)
    {
        QDialog dialog(this);
        QFormLayout form(&dialog);
        QList<QLineEdit *> fields_par;
        QLineEdit *lineEdit1 = new QLineEdit(&dialog);
        lineEdit1->setInputMethodHints(Qt::ImhPreferLatin);
        lineEdit1->setText(QString("New_File"));

        QString label1 = QString("File Name:");
        form.addRow(label1, lineEdit1);
        fields_par << lineEdit1;

        QDialogButtonBox buttonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel,
                                   Qt::Horizontal, &dialog);
        form.addRow(&buttonBox);
        QObject::connect(&buttonBox, SIGNAL(accepted()), &dialog, SLOT(accept()));
        QObject::connect(&buttonBox, SIGNAL(rejected()), &dialog, SLOT(reject()));


        //show keyboard on dial.show
        dialog.show();
        lineEdit1->setFocus();
        lineEdit1->selectAll();
        QInputMethod *keyboard = QGuiApplication::inputMethod();
        keyboard->show();

        //if Ok was clicked

        QString f_n;
        if (dialog.exec() == QDialog::Accepted)
        {
            f_n=lineEdit1->text();
            f_n+=".data";
            QFile f;
            f.setFileName(AppDir+f_n);
            if(f.exists())
            {
                QDialog DiaRewrite(this);
                QFormLayout form2(&DiaRewrite);
                QLabel label2("This file is already exist.\nOverwrite it?");
                form2.addRow(&label2);

                // Add some standard buttons (Cancel/Ok) at the bottom of the dialog
                QDialogButtonBox buttonBox2(QDialogButtonBox::Yes | QDialogButtonBox::Cancel,
                                           Qt::Horizontal, &DiaRewrite);
                form2.addRow(&buttonBox2);
                QObject::connect(&buttonBox2, SIGNAL(accepted()), &DiaRewrite, SLOT(accept()));
                QObject::connect(&buttonBox2, SIGNAL(rejected()), &DiaRewrite, SLOT(reject()));

                if (DiaRewrite.exec() != QDialog::Accepted)
                    return false;
            }

            //clear WS
            Clear();

        }
        else
            return false;

        file_name=f_n;
    }

    QFile qfile(AppDir+file_name);
    if (!qfile.open(QIODevice::WriteOnly | QIODevice::Text))
        return false;

    QTextStream out(&qfile);

    //ofstream file(dir_file.toLatin1().data(),std::ofstream::trunc);
    //if(!file) return false;

    for(int i=0;i<Drawables.size();i++)
    {
        Gr_DrawCore *o=Drawables[i];
        //don't save deleted items
        if(!o->isDrawn) continue;
        out << o->core_type << " " << o->calcInd << " " << o->x << " " << o->y << " " << o->isRotated << endl;
        for(int i=0;i<o->pars.size();i++)
        {
            out << o->pars[i];
            if(i<o->pars.size()-1)
                out << " ";
        }
        out << endl;
        for(int i=0;i<o->states.size();i++)
        {
            out << o->states[i];
            if(i<o->states.size()-1)
                out << " ";
        }
        out << endl;
    }
    out << "%" << endl;
    for(int i=0;i<Lines.size();i++)
    {
        Gr_Line *l=Lines[i];
        out << l->in_obj->calcInd << " " << l->numIn << " "
            << l->out_obj->calcInd << " " << l->numOut << endl;
    }
    out << "%" << endl;
    out<<grid_step_smooth<<" "<<grid_offset_smoth_X<<" "<<grid_offset_smoth_Y<<endl;
    out<<Tsim<<" "<<Ssim;
    qfile.close();
    return true;
}

bool MainWindow::Load()
{
    QString f_n;
    QFileDialog dial(this);
    dial.setOptions(QFileDialog::HideNameFilterDetails);
    dial.setViewMode(QFileDialog::List);
    dial.setDirectory(AppDir);
    dial.showFullScreen();
    if(dial.exec())
    {
        if(dial.selectedFiles().size()==1)
            f_n=dial.selectedFiles()[0];
    }
    else
        return false;

    dir_file=f_n;

    //clear WS
    Clear();

    char read_buffer[MAX_STR_SIZE];
    QString buff;
    QTextStream scan;

    QFile qfile(dir_file);
    if (!qfile.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;
    QFileInfo fileInfo(qfile.fileName());
    file_name=fileInfo.fileName();

    QTextStream in(&qfile);

    while(!in.atEnd())
    {
        int c_type;
        int cId, xx, yy, rot;
        string str_pars,str_st;
        int n_par,n_st;
        Gr_DrawCore *o;


        buff=in.readLine();
        scan.setString(&buff);
        scan.seek(0);
        if(buff==QString("%")) break;

        scan>>c_type>>cId>>xx>>yy>>rot;

        n_par=Gr_Core::NumOfPars((core_obj_types)c_type);
        n_st=Gr_Core::NumOfStates((core_obj_types)c_type);
        o=AddBlock((core_obj_types)c_type);
        o->x=xx;
        o->y=yy;
        o->isRotated=rot;
        o->calcInd=cId;
        if(cId>calcInd) calcInd=cId+1;

        buff=in.readLine();;
        scan.setString(&buff);
        scan.seek(0);
        for(int i=0;i<n_par;i++)
        {
            float par;
            if(!scan.atEnd())
            {
                scan>>par;
                o->pars[i]=par;
                qDebug()<<par<<" ";
            }
        }
        buff=in.readLine();
        scan.setString(&buff);
        scan.seek(0);
        for(int i=0;i<n_st;i++)
        {
            float st;
            if(!scan.atEnd())
            {
                scan>>st;
                o->states[i]=st;
            }
        }
        qDebug()<<endl;
    }
    while(!in.atEnd())
    {
        buff=in.readLine();
        scan.setString(&buff);
        scan.seek(0);
        if(buff==QString("%")) break;
        int o_in,n_in,o_out,n_out;
        scan>>o_in>>n_in>>o_out>>n_out;

        Gr_Line *l=new Gr_Line();
        Gr_DrawCore *obj_in,*obj_out;
        bool flg_in=false,flg_out=false;
        for(int i=0;i<Drawables.size();i++)
        {
            if(Drawables[i]->calcInd==o_in)
            {
                obj_in=Drawables[i];
                flg_in=true;
            }
            if(Drawables[i]->calcInd==o_out)
            {
                obj_out=Drawables[i];
                flg_out=true;
            }
            if(flg_out && flg_in)
            {
                l->SetPi(obj_in,n_in);
                l->SetPo(obj_out,n_out);
                Lines.push_back(l);
                break;
            }
        }

    }

    buff=in.readLine();
    scan.setString(&buff);
    scan.seek(0);
    scan>>grid_step_smooth>>grid_offset_smoth_X>>grid_offset_smoth_Y;
    UpdGrid();

    buff=in.readLine();
    scan.setString(&buff);
    scan.seek(0);
    scan>>Tsim>>Ssim;
    qfile.close();
    return true;
}

/*Gr_DrawCore* MainWindow::AddBlock(drawable_events ev)
{    
    return AddBlock(FromDrawToCore(ev));
}*/

Gr_DrawCore* MainWindow::AddBlock(core_obj_types ct)
{
    Gr_DrawCore *obj=NULL;

    int pos_x=w_w/2+0.5;
    int pos_y=w_h/2+0.5;

    int n_in=Gr_Core::NumOfInputs(ct), n_out=Gr_Core::NumOfOutputs(ct);

    obj=new Gr_DrawCore(pos_x,pos_y,n_in,n_out,DRWABLE_WORKSPACE,ct);

    for(int i=0;i<Gr_Core::NumOfPars(ct);i++)
    {
        obj->pars[i]=1;
    }

    for(int i=0;i<Gr_Core::NumOfStates(ct);i++)
    {
        obj->states[i]=0;
    }

    LoadImg(obj);

    if(obj!=NULL)
    {
        obj->calcInd=GetCalcInd();
        Drawables.push_back(obj);
    }

    return obj;
}

void MainWindow::LoadImg(Gr_DrawCore *obj)
{
    switch (obj->core_type)
    {
    case COT_SOURCE:
        obj->LoadImg(":/images/elements/pic/el_const.png");
        break;
    case COT_ADD:
        obj->LoadImg(":/images/elements/pic/el_sum.png");
        break;
    case COT_GAIN:
        obj->LoadImg(":/images/elements/pic/el_gain.png");
        break;
    case COT_INTEG:
        obj->LoadImg(":/images/elements/pic/el_integrator.png");
        break;
    case COT_INTEG2:
        obj->LoadImg(":/images/elements/pic/el_integrator2.png");
        break;
    case COT_SCP:
        obj->LoadImg(":/images/elements/pic/el_scope.png");
        break;
    case COT_DELAY:
        obj->LoadImg(":/images/elements/pic/el_delay.png");
        break;
    case COT_AND:
        obj->LoadImg(":/images/elements/pic/el_and.png");
        break;
    case COT_OR:
        obj->LoadImg(":/images/elements/pic/el_or.png");
        break;
    case COT_NOT:
        obj->LoadImg(":/images/elements/pic/el_not.png");
        break;
    case COT_DIFF:
        obj->LoadImg(":/images/elements/pic/el_diff.png");
        break;
    case COT_PULSE:
        obj->LoadImg(":/images/elements/pic/el_puls.png");
        break;
    case COT_SIN_SOURCE:
        obj->LoadImg(":/images/elements/pic/el_sin_source.png");
        break;
    case COT_STEP:
        obj->LoadImg(":/images/elements/pic/el_step.png");
        break;
    case COT_TIME:
        obj->LoadImg(":/images/elements/pic/el_time.png");
        break;
    case COT_S0:
        obj->LoadImg(":/images/elements/pic/el_s0.png");
        break;
    case COT_S1:
        obj->LoadImg(":/images/elements/pic/el_s1.png");
        break;
    case COT_DISPLAY:
        break;
    case COT_SUB:
    case COT_DIV:
    case COT_MULT:
    case COT_SIGN:
    case COT_ABS:
    case COT_SQRT:
    case COT_SQR:
    case COT_POW:
    case COT_SIN:
    case COT_COS:
    case COT_TAN:
    case COT_ASIN:
    case COT_ACOS:
    case COT_ATAN:
    case COT_ATAN2:
    case COT_EXP:
    case COT_LOG10:
    case COT_LN:
    case COT_TRANSFER:
    case COT_HARMONIC:
    default:
        obj->LoadImg(":/images/elements/pic/no_image.png");
        break;
    }

}

void MainWindow::UpdGrid()
{
    GRID_STEP=(int)grid_step_smooth;
    GRID_OFFSET_X=(int)(grid_offset_smoth_X);
    GRID_OFFSET_Y=(int)(grid_offset_smoth_Y);
}

void MainWindow::Clear()
{
    Drawables.clear();
    Lines.clear();
    grid_step_smooth=GRID_STEP0;
    grid_offset_smoth_X=0;
    grid_offset_smoth_Y=0;
    UpdGrid();
}

void MainWindow::StartCalc()
{
    if(CoreThread.isRunning())
    {
        qDebug()<<"Error. Thread is still active";
        return;
    }

    if(GetSimData())
    {
        Save();
        Convert();
        Calc();
    }
}

void MainWindow::PrepareGra()
{
    Graph->Prepare();
}

void MainWindow::ClearHL()
{
    for(int i=0; i<Drawables.size();i++)
    {
        Drawables[i]->wasClicked=false;
    }
}

void MainWindow::DeleteObjs()
{
    //dialog "do you want to delete the files?"
    QDialog DiaDel(this);
    QFormLayout form2(&DiaDel);
    QLabel label2("Do you want to delete selected files?");
    form2.addRow(&label2);

    QDialogButtonBox buttonBox2(QDialogButtonBox::Yes | QDialogButtonBox::No,
                               Qt::Horizontal, &DiaDel);
    form2.addRow(&buttonBox2);
    QObject::connect(&buttonBox2, SIGNAL(accepted()), &DiaDel, SLOT(accept()));
    QObject::connect(&buttonBox2, SIGNAL(rejected()), &DiaDel, SLOT(reject()));

    if (DiaDel.exec() != QDialog::Accepted)
        return;

    for(int i=Drawables.size()-1;i>=0;i--)
    {
        if(Drawables[i]->wasClicked)
        {
            for(int j=Lines.size()-1;j>=0;j--)
            {
                if(Lines[j]->in_obj==Drawables[i] || Lines[j]->out_obj==Drawables[i])
                {
                    Lines.erase(Lines.begin()+j);
                }
            }
            //correct calcIndexes
            Drawables.erase(Drawables.begin()+i);
            for(int j=i;j<Drawables.size();j++)
            {
                Drawables[j]->calcInd--;
            }
            calcInd--;
        }
    }
}

void MainWindow::AppStateEv(Qt::ApplicationState state)
{
    if(state==Qt::ApplicationState::ApplicationSuspended)
        Save();
}

void MainWindow::AboutToQuit()
{
    Save();
}

void MainWindow::StopThread()
{
    graphUpd->stop();
    CoreThread.quit();
    CoreThread.wait();
    Graph->Prepare();
}

void MainWindow::ResetFlags()
{
    //stop timer
    tapHoldTimer->stop();
    //reset click
    clk.first=-1;
    clk.second=-1;
    //stop scrolling
    scroll=false;
    may_scroll=false;
    //stop dragging
    isDrag=0;
    drag_ind=-1;
    //stop offsetting grid
    isOffset=false;
    //press and hold
    ind_pressed=-1;
    isHold=false;
}

bool MainWindow::isBodyClick(int ind)
{
    return (Drawables[ind]->InputClicked(mX,mY))==-1 && (Drawables[ind]->OutputClicked(mX,mY))==-1;
}

void MainWindow::ResetDblClk()
{
    doubleClkTimer->stop();
    DoubleClkFlg=false;
    DblRotate=false;
    RotateInd=-1;
}


bool MainWindow::SetSAndP(Gr_DrawCore* o)
{
    int n_st,n_par;
    n_st=Gr_Core::NumOfStates(o->core_type);
    n_par=Gr_Core::NumOfPars(o->core_type);

    if(o->pars.size()!=n_par || o->states.size()!=n_st)
    {
        qDebug()<<"ERROR: can't set params or states"<<endl;
        return false;
    }

    if(n_st>0 || n_par>0)
    {
        //vibrate
        #if defined(Q_OS_ANDROID)
        vibrator.vibrate(VIBRATE_TIME);
        #endif

        QDialog dialog(this);
        dialog.setInputMethodHints(Qt::ImhPreferNumbers);
        // Use a layout allowing to have a label next to each field
        QFormLayout form(&dialog);

        QList<QLineEdit *> fields_par;
        if(n_par>0)
        {
            // Add text above the fields
            form.addRow(new QLabel("Parameters"));
            // Add the lineEdits with their respective labels
            for(int i = 0; i < n_par; ++i)
            {
                QLineEdit *lineEdit = new QLineEdit(&dialog);
                lineEdit->setInputMethodHints(Qt::ImhPreferNumbers);
                lineEdit->setValidator( new QDoubleValidator() );
                lineEdit->setText(QString::number(o->pars[i]));
                lineEdit->selectAll();
                QString label = QString("Par %1").arg(i + 1);
                form.addRow(label, lineEdit);

                fields_par << lineEdit;
            }
        }

        QList<QLineEdit *> fields_states;
        if(n_st>0)
        {
            // Add some text above the fields
            form.addRow(new QLabel("States"));
            for(int i = 0; i < n_st; ++i)
            {
                QLineEdit *lineEdit = new QLineEdit(&dialog);
                lineEdit->setInputMethodHints(Qt::ImhPreferNumbers);
                lineEdit->setValidator( new QDoubleValidator() );
                lineEdit->setText(QString::number(o->states[i]));
                lineEdit->selectAll();
                QString label = QString("State %1").arg(i + 1);
                form.addRow(label, lineEdit);

                fields_states << lineEdit;
            }
        }

        // Add some standard buttons (Cancel/Ok) at the bottom of the dialog
        QDialogButtonBox buttonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel,
                                   Qt::Horizontal, &dialog);
        form.addRow(&buttonBox);
        QObject::connect(&buttonBox, SIGNAL(accepted()), &dialog, SLOT(accept()));
        QObject::connect(&buttonBox, SIGNAL(rejected()), &dialog, SLOT(reject()));

        //show keyboard
        dialog.show();
        if(fields_par.size()>0)
        {
            fields_par[0]->setFocus();
            fields_par[0]->selectAll();
        }
        else  if(fields_states.size()>0)
        {
            fields_states[0]->setFocus();
            fields_states[0]->selectAll();
        }
        QInputMethod *keyboard = QGuiApplication::inputMethod();
        keyboard->show();

        // Show the dialog as modal
        if (dialog.exec() == QDialog::Accepted)
        {
            // If the user didn't dismiss the dialog, do something with the fields
            for(int i=0;i<fields_par.size();i++)
            {
                double val=fields_par[i]->text().replace(',','.').toDouble();
                o->pars[i]=val;
            }
            for(int i=0;i<fields_states.size();i++)
            {
                double val=fields_states[i]->text().replace(',','.').toDouble();
                o->states[i]=val;
            }
        }
        return  true;
    }
    return false;
}



